// content_script.js
(function() {
  console.log("[RobloxPaster CS] content script loaded");

  function applyCodeToInput(code) {
    try {
      const input = document.querySelector("#code-input");
      if (!input) return false;

      const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
      if (setter) setter.call(input, code);
      else input.value = code;

      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
      input.focus();

      console.log("[RobloxPaster CS] Applied code to input");
      return true;
    } catch (e) {
      console.error("[RobloxPaster CS] applyCodeToInput error", e);
      return false;
    }
  }

  function clickRedeemButton() {
    const button = document.querySelector("button.redeem-btn.btn-primary-lg.btn-full-width");
    const input = document.querySelector("#code-input");
    if (button && input && input.value) {
      button.disabled = false;
      const evt = new MouseEvent('click', { bubbles: true, cancelable: true, view: window });
      button.dispatchEvent(evt);
      console.log("[RobloxPaster CS] Redeem button clicked");
      return true;
    }
    return false;
  }

  browser.runtime.onMessage.addListener((message) => {
    if (!message || message.type !== "pasteCode") return;

    const code = message.code || "";
    console.log("[RobloxPaster CS] Received code to paste:", code);

    let attempts = 0;
    const maxAttempts = 200;
    const intervalMs = 200;

    return new Promise((resolve) => {
      const interval = setInterval(() => {
        attempts++;
        const inputOk = applyCodeToInput(code);
        const buttonOk = clickRedeemButton();

        if (inputOk && buttonOk) {
          clearInterval(interval);
          console.log("[RobloxPaster CS] Code injected and Redeem clicked on attempt", attempts);
          resolve({ ok: true, attempts });
        } else if (attempts >= maxAttempts) {
          clearInterval(interval);
          console.warn("[RobloxPaster CS] Failed after max attempts");
          resolve({ ok: false, attempts });
        } else if (attempts % 5 === 0) {
          console.log("[RobloxPaster CS] Retry attempt", attempts);
        }
      }, intervalMs);
    });
  });
})();
