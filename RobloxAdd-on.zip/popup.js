const toggle = document.getElementById('randomToggle');
const status = document.getElementById('status');
let running = false;

function generateRandomCode() {
  function randomDigits(n) {
    let s = "";
    for (let i = 0; i < n; i++) s += Math.floor(Math.random() * 10);
    return s;
  }
  return `${randomDigits(3)}-${randomDigits(3)}-${randomDigits(4)}`;
}

async function tryRandomCodes(tab) {
  let attempts = 0;
  while (running) {
    const randomCode = generateRandomCode();
    attempts++;
    status.textContent = `Running... Attempts: ${attempts}, Last code: ${randomCode}`;

    try {
      // Send code and request autoClick
      await browser.tabs.sendMessage(tab.id, { type: "pasteCode", code: randomCode, autoClick: true });
      console.log("[RandomRedeemer] Tried code:", randomCode);
    } catch (e) {
      console.warn("[RandomRedeemer] Content script not ready?", e);
    }

    // Wait until the Redeem button is enabled again before the next attempt
    await new Promise(resolve => {
      const checkInterval = setInterval(() => {
        browser.tabs.executeScript(tab.id, {
          code: `
            !!document.querySelector("button.redeem-btn.btn-primary-lg.btn-full-width:not([disabled])");
          `
        }).then(results => {
          if (results[0]) {
            clearInterval(checkInterval);
            resolve();
          }
        });
      }, 300); // check every 300ms
    });
  }
}

toggle.addEventListener('change', async () => {
  const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
  if (!tab.url.includes("/redeem")) {
    status.textContent = "Not on redeem page!";
    toggle.checked = false;
    return;
  }

  if (toggle.checked) {
    running = true;
    status.textContent = "Running...";
    tryRandomCodes(tab);
  } else {
    running = false;
    status.textContent = "Stopped.";
  }
});
