// background.js

// Regex pattern for numeric Roblox code XXX-XXX-XXXX
const robloxCodePattern = /^\d{3}-\d{3}-\d{4}$/;

// Create the context menu but keep it hidden initially
browser.runtime.onInstalled.addListener(() => {
  try {
    browser.contextMenus.create({
      id: "pasteRobloxCode",
      title: "Paste Roblox Code V:3.0",
      contexts: ["selection"],
      visible: false // initially hidden
    });
  } catch (e) {
    console.error("contextMenus.create error", e);
  }
});

// Show/hide the menu depending on selection
browser.contextMenus.onShown.addListener((info, tab) => {
  const code = info.selectionText?.trim() || "";
  const shouldShow = robloxCodePattern.test(code);

  browser.contextMenus.update("pasteRobloxCode", { visible: shouldShow });
  // Needed to actually refresh the menu
  browser.contextMenus.refresh();
});

browser.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== "pasteRobloxCode") return;

  const code = info.selectionText?.trim() || "";
  if (!code) return;

  // Open the redeem page in a new tab
  browser.tabs.create({ url: "https://www.roblox.com/redeem" }).then((newTab) => {
    const send = () => {
      browser.tabs.sendMessage(newTab.id, { type: "pasteCode", code }).then(
        (response) => {
          console.log("background: message delivered, response:", response);
        },
        (err) => {
          console.log("background: sendMessage failed (content script not ready yet) — will retry:", err);
        }
      );
    };

    setTimeout(send, 400);
    setTimeout(send, 1200);
    setTimeout(send, 3000);
  }).catch((err) => {
    console.error("Failed to open redeem tab", err);
  });
});
